function [Hs, Hrms, T, Etot] = WaveChar(Freq, a)
%WAVECHAR calculates the wave charecteristiscs
%
% Input:
%   Freq    Frequencies (vector)
%   a       plitude of frequency spectrum
%
% Output:
%   Hs      significant wave height (m)
%   Hrms    root-mean-square wave height (m)
%   T       peak period (s)
%   Etot    total wave energy (J m^-2)
%
% Version 1.0 (08/06/2014)
% Coded and developed by Jim van Belzen
% published under the Creative Commons Attribution Non-Commercial license 
% which allows users to read, copy, distribute and make derivative works 
% for noncommercial purposes from the material, as long as the author of 
% the original work is cited.
% This code comes with no warranties or support
% http://people.zeelandnet.nl/jbelzen/

%% constants
g=9.81;
rho_salt=1024;

%%
Etot=sum(0.5*a.^2*g*rho_salt);

Hs=4*sqrt(Etot*(1/(g*rho_salt)));

Hrms=2*sqrt(2)*sqrt(Etot*(1/(g*rho_salt)));

[i j]=max(a);

T=1/Freq(j);

end