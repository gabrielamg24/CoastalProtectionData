function [hcorr] = AttenCorr(Freq, h, z_inst)
%ATTENCORR calculates the correction factor for depth attenuation
%
% Input:
%   Freq    Frequencies (vector)
%   h       water depth (in m)
%   z_inst  height of pressure sensor above bottom
%
% Output:
%   hcorr   correction factor for depth attenuation (vector)
%
% Version 1.0 (08/06/2014)
% Coded and developed by Jim van Belzen
% published under the Creative Commons Attribution Non-Commercial license 
% which allows users to read, copy, distribute and make derivative works 
% for noncommercial purposes from the material, as long as the author of 
% the original work is cited.
% This code comes with no warranties or support
% http://people.zeelandnet.nl/jbelzen/

%%
on=1;
off=0;
GraphOn=off;

% frequency limits for correction
min_f=0.05;
max_f=0.66;
% maximum correction factor
max_corr=5;

%% calculate wavenumber
k=wavenum(Freq, h);

%% determine correction
if h>z_inst,
    hcorr=1./(cosh(k*z_inst)./cosh(k*h)).^2;
    hcorr(Freq<min_f | Freq>max_f)=1;
    hcorr=min(hcorr,max_corr);
else
    [row,col]=size(Freq);
    hcorr=ones(row,col);
end

%% Plot single-sided amplitude spectrum.
if GraphOn==on,
    figure,
    plot(Freq,hcorr) 
    title('Factor to correct for depth attenuation')
    xlabel('Frequency (Hz)')
    ylabel('Correction factor')
end

end

