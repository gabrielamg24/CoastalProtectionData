function [a, freq] = WaveSpectrum(x, Fs, win)
%WAVESPECTRUM calculates wave spectrum from high-resolution time series
%
% Input:
%   x       wave data
%   Fs      Sampling frequency (Hz)
%   win     window size
%
% Output:
%   a       Amplitude (vector)
%   freq    Frequencies corresponding with amplitude (vector)
%
% Version 1.0 (04/06/2014)
% Version 2.0 (06/06/2014)
% Coded and developed by Jim van Belzen
% published under the Creative Commons Attribution Non-Commercial license 
% which allows users to read, copy, distribute and make derivative works 
% for noncommercial purposes from the material, as long as the author of 
% the original work is cited.
% This code comes with no warranties or support
% http://people.zeelandnet.nl/jbelzen/

on=1;
off=0;

GraphOn=off;

N0=numel(x);
xx=reshape(x(1:floor(N0/win)*win),win,floor(N0/win));
xxx=x(floor(win/2):end);
N1=numel(xxx);
xxx=reshape(xxx(1:floor(N1/win)*win),win,floor(N1/win));
xx=[xx, xxx];
clear xxx

xx_det=detrend(xx);

Nfft=2^nextpow2(win); % Next power of 2 from length of y

Y=fft(xx_det,Nfft)/win;Y(1,:)=0;
a=2*abs(Y(1:Nfft/2+1,:));
a=mean(a,2);

freq=Fs/2*linspace(0,1,Nfft/2+1); 
freq=freq';

%% Plot single-sided amplitude spectrum.
if GraphOn==on,
    figure,
    plot(freq,a) 
    title('Amplitude Spectrum of x(t)')
    xlabel('Frequency (Hz)')
    ylabel('A(f)')
end

end

