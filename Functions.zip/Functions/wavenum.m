function [k] = wavenum(Freq, h)
%WAVENUM calculates the wavenumber based on dispersion relation.
% Estimation is solved using the polynomial approximation
%
% Input:
%   Freq    Frequencies (vector)
%   h       water depth (in m)
%
% Output:
%   k       wavenumber correspinding to frequency (vector)
%
% Version 1.0 (08/06/2014)
% Based on George Voulgaris, SUDO, 1992
% Coded and developed by Jim van Belzen
% published under the Creative Commons Attribution Non-Commercial license 
% which allows users to read, copy, distribute and make derivative works 
% for noncommercial purposes from the material, as long as the author of 
% the original work is cited.
% This code comes with no warranties or support
% http://people.zeelandnet.nl/jbelzen/

g=9.81; % acceleration of gravity (m/s^2)

w=2*pi*Freq;

q1=(w.^2)*h/g;
q2=q1+(1+0.6522*q1+0.4622*q1.^2+0.0864*q1.^4+0.0675*q1.^5).^-1;
q3=sqrt(9.81*h*q2.^-1)./Freq;

k=2*pi*q3.^-1;

end

