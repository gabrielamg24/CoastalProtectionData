% ReadFolder
%
% Version 1.0 (28/03/2012)
% Copyright (c) 2012, Jim van Belzen
% http://people.zeelandnet.nl/jbelzen/

clear all
clc

% Setup directories
mainDirectory = '/Users/Gabriela/Desktop/RUG/Project 1//DATA/waveloggersw/MATLAB';

inputDirectory = strcat(mainDirectory,'/Input');
rawDirectory = strcat(mainDirectory,'/Raw');
outputDirectory = strcat(mainDirectory,'/Output');

cd(rawDirectory)
% Reformat raw data files in the /Raw folder
% Processed datafiles will be placed in the /Input folder

fileNames = dir('*WLOG_*.CSV');
fileNumber = length(fileNames);

data = [];
temp = [];
A0 = [];

j = 1;
for i = 1:(fileNumber),
    fileName = fileNames(i).name;
    fidr = fopen(fileName, 'rt');
    i = 1; ii = 1;
    
    while feof(fidr) == 0,
        tline = fgetl(fidr);
        A = sscanf(tline, '%f');
        if isempty(A) == 0,
            a = textscan(tline,'%f','delimiter',',');
            D = a{1,1};
            if numel(D) == 13,
                data(i:(i + 11),j) = D(1:12);
                temp(ii,j) = D(13);
                i = i + numel(D) - 1;
                ii = ii + 1;
            end
        end
        if (isempty(A0) == 0) && (isempty(A) == 1),
            j = j + 1;
            i = 1; ii = 1;
        end
        A0 = A;
    end
    fclose(fidr);
end
cd(inputDirectory)
csvwrite('bursts.csv',data)
csvwrite('temp.csv',temp)
